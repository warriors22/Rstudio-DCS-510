---
date: "2020-10-05T21:48:51-07:00"
title: About 
---

About the author: Hi I'm Josh Howard. I am a high school math teacher as well as basketball and baseball coach. I been married for 12 years and have a 3 year old son who keeps me busy. I love spending time with my family and watching my son grow up.  I am a graduate of UNC (Go Heels!) and I am currently enrolled at Carolina University studying Data Science. One of my favorite hobbies is fantasy football and I really enjoy trying to find patterns in the numbers behind the game.  
